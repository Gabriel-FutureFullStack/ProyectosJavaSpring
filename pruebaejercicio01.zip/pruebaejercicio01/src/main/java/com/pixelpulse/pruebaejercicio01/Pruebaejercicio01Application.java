package com.pixelpulse.pruebaejercicio01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pruebaejercicio01Application {

	public static void main(String[] args) {
		SpringApplication.run(Pruebaejercicio01Application.class, args);
	}

}
