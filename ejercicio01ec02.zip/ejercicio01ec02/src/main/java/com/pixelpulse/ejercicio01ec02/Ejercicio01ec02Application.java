package com.pixelpulse.ejercicio01ec02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio01ec02Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio01ec02Application.class, args);
	}

}
