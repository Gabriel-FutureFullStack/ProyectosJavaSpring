package com.pixelpulse.ejercicio01ec02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio01ec02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
