package com.pixelpulse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Semana03Application {

	public static void main(String[] args) {
		SpringApplication.run(Semana03Application.class, args);
	}

}
