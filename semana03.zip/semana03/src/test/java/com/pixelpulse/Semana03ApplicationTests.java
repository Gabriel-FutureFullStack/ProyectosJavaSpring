package com.pixelpulse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Semana03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
