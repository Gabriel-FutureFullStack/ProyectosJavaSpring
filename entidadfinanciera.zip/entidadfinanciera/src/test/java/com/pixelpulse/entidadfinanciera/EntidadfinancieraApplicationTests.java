package com.pixelpulse.entidadfinanciera;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntidadfinancieraApplicationTests {

	@Test
	void contextLoads() {
	}

}
