package com.pixelpulse.escuela;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EscuelaApplicationTests {

	@Test
	void contextLoads() {
	}

}
