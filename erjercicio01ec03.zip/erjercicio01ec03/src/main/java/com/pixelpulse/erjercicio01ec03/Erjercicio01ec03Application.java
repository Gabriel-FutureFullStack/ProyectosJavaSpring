package com.pixelpulse.erjercicio01ec03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Erjercicio01ec03Application {

	public static void main(String[] args) {
		SpringApplication.run(Erjercicio01ec03Application.class, args);
	}

}
