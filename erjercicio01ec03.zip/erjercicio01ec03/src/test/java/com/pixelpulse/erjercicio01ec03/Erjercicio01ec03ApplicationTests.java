package com.pixelpulse.erjercicio01ec03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Erjercicio01ec03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
