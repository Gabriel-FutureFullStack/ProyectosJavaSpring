package com.pixelpulse.diamante;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiamanteApplicationTests {

	@Test
	void contextLoads() {
	}

}
