package com.pixelpulse.diamante;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiamanteApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiamanteApplication.class, args);
	}

}
